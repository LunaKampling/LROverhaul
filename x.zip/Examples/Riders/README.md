# How to create a custom rider

In the /Documents/LRA/ directory add a new folder called "Riders"
In the Riders folder and add a folder that is the name of the rider
In the new folder paste/edit the files from /src/Resources/rider to create a new rider
You can then select the rider in the Preferences -> LRTran -> Rider Settings -> Selected Rider

