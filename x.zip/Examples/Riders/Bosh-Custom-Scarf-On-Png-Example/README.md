# Custom scarves on a rider image
This is a template / working example of a rider image that can have a custom scarf applied to it.  

Edit the palette.png image to determine what colors it'll change.  

To add more colors to a scarf image expand palette.png's size.