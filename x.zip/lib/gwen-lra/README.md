## This likely isn't the repository you're looking for

This is a sparsely supported version of https://code.google.com/archive/p/gwen-dotnet/ with features only maintained specifically for use with [linerider-advanced](https://github.com/jealouscloud/linerider-advanced)