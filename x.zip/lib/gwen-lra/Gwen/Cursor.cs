using System;
namespace Gwen
{
    public class Cursor
    {
        public readonly string Name;
        public Cursor(string name)
        {
            Name = name;
        }
    }
}