﻿using System;
using System.Drawing;

namespace Gwen.Controls
{
    public interface IColorPicker
    {
        Color SelectedColor { get; }
    }
}
