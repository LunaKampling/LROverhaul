﻿using System;

namespace Gwen
{
    public struct HSV
    {
        public float h;
        public float s;
        public float v;
    }
}
