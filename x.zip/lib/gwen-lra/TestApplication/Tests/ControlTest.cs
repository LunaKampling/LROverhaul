﻿using System;
using Gwen.Controls;
namespace TestApplication
{
    public class ControlTest
    {
        public ControlBase Parent;
        public ControlTest(ControlBase parent)
        {
            Parent = parent;
        }
    }
}
