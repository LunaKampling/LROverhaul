﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linerider.Tools
{
    class SharedSwatches
    {
        public static Swatch DrawingToolsSwatch = new Swatch();
        public static Swatch EraserAndSelectToolSwatch = new Swatch();
    }
}
