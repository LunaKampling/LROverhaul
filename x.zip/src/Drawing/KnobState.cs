
namespace linerider.Drawing
{
    public enum KnobState
    {
        Hidden = 0,
        Shown = 1,
        LifeLock = 2,
    }
}