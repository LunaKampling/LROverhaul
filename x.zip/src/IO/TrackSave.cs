﻿using System;
namespace linerider.IO
{
    public class TrackSave
    {
        public TrackSave()
        {
        }
    }
}
