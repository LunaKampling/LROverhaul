using System;
namespace linerider.IO
{
    public static class TrackFeatures
    {
        public const string redmultiplier = "REDMULTIPLIER";
        public const string scenerywidth = "SCENERYWIDTH";
        public const string six_one = "6.1";
        public const string songinfo = "SONGINFO";
        public const string ignorable_trigger = "IGNORABLE_TRIGGER";
        public const string zerostart = "ZEROSTART";
        public const string remount = "REMOUNT";
        public const string frictionless = "FRICTIONLESS";
    }
}