namespace linerider.Game
{
    public enum SelectionState
    {
        None = 0,
        Selected = 1,
        Hovered = 2,
    }
}