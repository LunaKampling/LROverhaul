# Changelogs folder

This folder contains the previous changelogs for LRTran!